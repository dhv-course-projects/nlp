import numpy as np
import gensim.downloader as api
from constants import w2v_path,words_path,w2v_download_path,t2v_path,tags_path

class FormatSentence:

    @staticmethod
    def vectorizeElements(A,N,L,vL,typ):
        '''
        shape(A) = (N,L)
        shape(X) = (N,L*vL)
        '''
        X = np.zeros((N,L*vL))
        for i,s in enumerate(A):
            x = WordVector.loadData(s,vL,typ)
            X[i] = np.reshape(x,L*vL)
        return X

    @staticmethod
    def breakSequence(S,L,dummy):
        '''
        S is list of sentences of shape (N,?,2)
        returns array of sentences of shape (N',L,2) and
        returns array of indices to map to previous sentences
        '''

        def fillDummy(s):
            while len(s) < L:
                s.append(dummy)
            return s

        S1 = []
        idx = []
        for s in S:
            for i in range(0,len(s),L):
                S1.append(fillDummy(s[i:min(len(s),i+20)]))
                idx.append(i)
        return S1,idx

    @staticmethod
    def seperate(ST):
        S = []
        T = []
        for st in ST:
            S += st[:][0]
            T += st[:][1]
        return S,T

class WordVector:

    @staticmethod
    def loadData(lst,vL,typ):
        L = len(lst)
        lstV = np.zeros((L,vL))
        embeddings = []
        obj = {}

        if typ == 'words':
            embeddings = np.load(w2v_path)
            obj = np.load(words_path,allow_pickle=True)
        elif typ == 'tags':
            embeddings = np.load(t2v_path)
            obj = np.load()

        for i in range(L):
            if lst[i] in obj:
                lstV[i] = embeddings[obj[lst[i]]]

        return lstV


# class Preprocess:

