import numpy as np
import torch
from torch import nn
from Utils import FormatSentence
from constants import DummyTag, DummyWord

class NeuralNetwork(nn.Module):
    def __init__(self,M0,M1,M2,K):
        super().__init__()
        self.M0 = M0
        self.M1 = M1
        self.M2 = M2
        self.K = K

        self.W1 = nn.Parameter(torch.randn(M0,M1).double())
        # self.W2 = nn.Parameter(torch.randn(M1,M2).double())
        self.W3 = nn.Parameter(torch.randn(M1,K).double())

    def forward(self,X):
        pred = torch.sigmoid(torch.matmul(X,self.W1))
        # pred = torch.sigmoid(torch.matmul(pred,self.W2))
        pred = torch.softmax(torch.matmul(pred,self.W3),dim=1)
        return pred

class POS_tagging:
    def __init__(self,ST):
        super().__init__()
        self.L = 50
        self.wvL = 300
        self.tvL = 12
        self.M1 = 10000
        self.M2 = 5000
        self.LR = 0.2

        S,T = FormatSentence.seperate(ST)
        S1,idxS = FormatSentence.breakSequence(S,self.L,DummyWord)
        T1,idxT = FormatSentence.breakSequence(T,self.L,DummyTag)
        self.N = len(S1)
        self.X = FormatSentence.vectorizeElements(S1,self.N,self.L,self.wvL,'words')
        self.Y = FormatSentence.vectorizeElements(T1,self.N,self.L,self.tvL,'tags')

        self.network = NeuralNetwork(self.L*self.wvL,self.M1,self.M2,self.L*self.tvL)
        self.optim = torch.optim.SGD(self.network.parameters(), self.LR)

    def train():
        pass