import numpy as np
from constants import w2v_path

# WordToVector.saveEmbeddings(w2v_path)

if __name__ == '__main__':
    
    wv = np.load(w2v_path)

    print(wv)